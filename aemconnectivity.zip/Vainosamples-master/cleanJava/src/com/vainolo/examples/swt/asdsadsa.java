/*******************************************************************************
 * Copyright (c) 2012 Arieh 'Vainolo' Bibliowicz
 * You can use this code for educational purposes. For any other uses
 * please contact me: vainolo@gmail.com
 *******************************************************************************/
package com.vainolo.examples.swt;

import org.eclipse.swt.widgets.Composite;

public class asdsadsa extends Composite {

  /**
   * Create the composite.
   * @param parent
   * @param style
   */
  public asdsadsa(Composite parent, int style) {
    super(parent, style);

  }

  @Override
  protected void checkSubclass() {
    // Disable the check that prevents subclassing of SWT components
  }

}
