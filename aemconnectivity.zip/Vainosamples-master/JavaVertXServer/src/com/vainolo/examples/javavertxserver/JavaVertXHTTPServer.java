package com.vainolo.examples.javavertxserver;

public class JavaVertXHTTPServer {
  public static void main(String args[]) {
    System.out.println("Hello World");
  }

}
