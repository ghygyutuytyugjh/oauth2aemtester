/*******************************************************************************
 * Copyright (c) 2012 Arieh 'Vainolo' Bibliowicz
 * You can use this code for educational purposes. For any other uses
 * please contact me: vainolo@gmail.com
 *******************************************************************************/
package com.vainolo.gef.template;

import org.eclipse.ui.part.EditorActionBarContributor;

/**
 * Nothing much done here yet... This is a placeholder for more functionality
 * that will be added in future releases.
 * 
 * @author vainolo
 * 
 */
public class GEFEditorTemplateActionBarContributor extends EditorActionBarContributor {

  public GEFEditorTemplateActionBarContributor() {

  }

}
